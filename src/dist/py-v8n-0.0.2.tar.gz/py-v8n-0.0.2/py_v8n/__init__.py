from .Validator import Validator


def v8n():
    return Validator([], False)
